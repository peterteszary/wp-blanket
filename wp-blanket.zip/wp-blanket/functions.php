<?php
 // nothing here
 // add functions with a plugin like Code Snippets (https://wordpress.org/plugins/code-snippets/), Advanced Scripts (https://www.cleanplugins.com/products/advanced-scripts/), or Scripts Organizer (https://docs.dplugins.com/scripts-organizer/scripts-organizer/)
?>
